<?php

	if(isset($_GET['submit']))
	{
		$fn = "";
		$ln = "";
		$fn = $_GET['firstname'];
		$ln = $_GET['lastname'];
		$email = $_GET['email'];
		
if($fn == "")
{
	echo "Error ! First name can not be empty";
	echo '<br>';
}
 else {

        if (strlen($fn) < 2) {
            echo 'Error ! First Name is too short';
            echo '<br>';
        }
		else {
            if (is_numeric(substr($fn, 0, 1)) || substr($fn, 0, 1) == '.' || substr($fn, 0, 1) == '-') {
                echo 'Error ! In First Name, First character can not  be Character or Numeric';
                echo '<br>';
            }
			else {



                $first_name_array = str_split($fn, 1);

                foreach ($first_name_array as $value) {

                    if ($value == '.' || $value == '-' || $value == 'A' || $value == 'B' || $value == 'C' || $value == 'D' || $value == 'E' || $value == 'F' || $value == 'G' || $value == 'H' || $value == 'I' || $value == 'J' || $value == 'K' || $value == 'L' || $value == 'M' || $value == 'N' || $value == 'O' || $value == 'P' || $value == 'Q' || $value == 'R' || $value == 'S' || $value == 'T' || $value == 'U' || $value == 'V' || $value == 'W' || $value == 'X' || $value == 'Y' || $value == 'Z' || $value == 'a' || $value == 'b' || $value == 'c' || $value == 'd' || $value == 'e' || $value == 'f' || $value == 'g' || $value == 'h' || $value == 'i' || $value == 'j' || $value == 'k' || $value == 'l' || $value == 'm' || $value == 'n' || $value == 'o' || $value == 'p' || $value == 'q' || $value == 'r' || $value == 's' || $value == 't' || $value == 'u' || $value == 'v' || $value == 'w' || $value == 'x' || $value == 'y' || $value == 'z') {
                        
                    } else {
                        echo 'Error ! Invalid Character in First Name';
                        echo '<br>';
                        break;
                    }
                }
            }
	}
 }
 
 
 
 
 if($fn == "")
{
	echo "Error ! Last name can not be empty";
	echo '<br>';
}
 else {

        if (strlen($fn) < 2) {
            echo 'Error ! Last Name is too short';
            echo '<br>';
        }
		else {
            if (is_numeric(substr($fn, 0, 1)) || substr($fn, 0, 1) == '.' || substr($fn, 0, 1) == '-') {
                echo 'Error ! In Last Name, First character can not  be Character or Numeric';
                echo '<br>';
            }
			else {



                $last_name_array = str_split($fn, 1);

                foreach ($last_name_array as $value) {

                    if ($value == '.' || $value == '-' || $value == 'A' || $value == 'B' || $value == 'C' || $value == 'D' || $value == 'E' || $value == 'F' || $value == 'G' || $value == 'H' || $value == 'I' || $value == 'J' || $value == 'K' || $value == 'L' || $value == 'M' || $value == 'N' || $value == 'O' || $value == 'P' || $value == 'Q' || $value == 'R' || $value == 'S' || $value == 'T' || $value == 'U' || $value == 'V' || $value == 'W' || $value == 'X' || $value == 'Y' || $value == 'Z' || $value == 'a' || $value == 'b' || $value == 'c' || $value == 'd' || $value == 'e' || $value == 'f' || $value == 'g' || $value == 'h' || $value == 'i' || $value == 'j' || $value == 'k' || $value == 'l' || $value == 'm' || $value == 'n' || $value == 'o' || $value == 'p' || $value == 'q' || $value == 'r' || $value == 's' || $value == 't' || $value == 'u' || $value == 'v' || $value == 'w' || $value == 'x' || $value == 'y' || $value == 'z') {
                        
                    } else {
                        echo 'Error ! Invalid Character in Last Name';
                        echo '<br>';
                        break;
 
					}
                }
            }
	}
 }

 
 
 
 
 
    if (!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $email)){ 

		echo "<center>Invalid email</center>";

	}else{

		echo "<center>Valid Email</center>";
	}
}







	
    if (!isset($_GET['gender'])) {
        echo 'Error ! One Gender must be selected';
        echo '<br>';
		
    } else {
        $gender = $_GET['gender'];
    }
	
	
	
	
	
	
	
     
    if ($_GET['date'] == "") {

		echo ' Fillup the Date !';
	
	}
?>